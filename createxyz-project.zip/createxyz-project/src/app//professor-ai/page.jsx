"use client";
import React from "react";

import {
  useUpload,
  useHandleStreamResponse,
} from "../utilities/runtime-helpers";

function MainComponent() {
  const [question, setQuestion] = useState("");
  const [streamingAnswer, setStreamingAnswer] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [history, setHistory] = useState([]);
  const [showHistory, setShowHistory] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [error, setError] = useState(null);

  // Load history from localStorage on mount
  useEffect(() => {
    const savedHistory = localStorage.getItem("professorAI_history");
    if (savedHistory) {
      setHistory(JSON.parse(savedHistory));
    }
  }, []);

  // Save history to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("professorAI_history", JSON.stringify(history));
  }, [history]);

  const handleFinish = useCallback(
    (message) => {
      const newEntry = {
        id: Date.now(),
        question: question,
        answer: message,
        timestamp: new Date().toLocaleString(),
      };
      setHistory((prev) => [newEntry, ...prev]);
      setStreamingAnswer("");
      setIsLoading(false);
    },
    [question]
  );

  const handleStreamResponse = useHandleStreamResponse({
    onChunk: setStreamingAnswer,
    onFinish: handleFinish,
  });

  const handleSubmit = async () => {
    if (!question.trim()) return;

    setError(null);
    setIsLoading(true);
    setStreamingAnswer("");

    try {
      const response = await fetch(
        "/integrations/anthropic-claude-sonnet-3-5/",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            messages: [
              {
                role: "system",
                content:
                  "You are Professor AI, a super friendly teacher who explains things to 5th grade students (10-11 years old). Your job is to make learning fun and easy!\n\nIMPORTANT RULES FOR 5TH GRADERS:\n1. Use VERY SIMPLE words - no big complicated words\n2. Explain EVERY step like you're showing a 10-year-old\n3. NO confusing symbols - write everything in simple text\n4. Make it fun and easy to understand\n5. Check your math twice to make sure it's 100% correct\n6. Show ALL your work step by step\n7. Use examples they can relate to (like pizza, toys, sports, candy)\n8. Always encourage the student - say things like 'Great question!' or 'You're doing awesome!'\n\nFORMATTING RULES (VERY IMPORTANT):\n- Write fractions as: 3 out of 4 or 3/4\n- Write multiplication as: 3 times 4 or 3 x 4\n- Write division as: 12 divided by 3 or 12/3\n- Write exponents as: 5 squared or 5 to the power of 2\n- Write square roots as: square root of 16\n- NO fancy symbols like ×, ÷, ², ³, √, π, ∞, ≤, ≥, ±, ∑, ∫\n- Use simple words: plus, minus, times, divided by\n- Number each step clearly: Step 1, Step 2, Step 3\n- Use lots of spacing between steps\n- Explain WHY we do each step\n- Use fun examples: 'Imagine you have 12 cookies...'\n\nEXAMPLE FORMAT:\nGreat question! Let me help you solve this step by step.\n\nStep 1: What do we know?\n- Write down all the numbers given\n- Explain what each number means in simple words\n\nStep 2: What do we need to find?\n- Say clearly what we're looking for\n- Use simple words to explain\n\nStep 3: What method do we use?\n- Write the formula or rule in simple words\n- Explain what each part means\n\nStep 4: Let's solve it step by step:\n- Put in the numbers\n- Do the math one step at a time\n- Show every single calculation\n- Explain each step as we go\n\nStep 5: Check our answer:\n- Does it make sense?\n- Let's double-check our math\n- Use a real-world example to verify\n\nFinal Answer: [Write the answer clearly and celebrate!]\n\nRemember: Always be encouraging and explain everything like you're talking to a 10-year-old who is just learning. Make math and learning fun!",
              },
              {
                role: "user",
                content: question,
              },
            ],
            stream: true,
          }),
        }
      );

      if (!response.ok) {
        throw new Error(`Error: ${response.status} ${response.statusText}`);
      }

      handleStreamResponse(response);
    } catch (err) {
      console.error("Error asking Professor AI:", err);
      setError(
        "Sorry, I had trouble processing your question. Please try again."
      );
      setIsLoading(false);
    }
  };

  const handleVoiceInput = () => {
    if (
      !("webkitSpeechRecognition" in window) &&
      !("SpeechRecognition" in window)
    ) {
      setError("Voice input is not supported in your browser.");
      return;
    }

    const SpeechRecognition =
      window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();

    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = "en-US";

    recognition.onstart = () => {
      setIsListening(true);
      setError(null);
    };

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      setQuestion(transcript);
      setIsListening(false);
    };

    recognition.onerror = (event) => {
      setError("Voice recognition error. Please try again.");
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognition.start();
  };

  const [upload, { loading: uploadLoading }] = useUpload();

  const handleImageUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    // Check file type
    const allowedTypes = [
      "image/png",
      "image/jpeg",
      "image/jpg",
      "image/webp",
      "image/gif",
    ];
    if (!allowedTypes.includes(file.type)) {
      setError("Please upload a PNG, JPEG, WEBP, or GIF image.");
      return;
    }

    setError(null);
    setIsLoading(true);
    setStreamingAnswer("");

    try {
      // Convert file to base64
      const base64 = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });

      // Use GPT-4 Vision to analyze the image
      const response = await fetch("/integrations/gpt-vision/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [
            {
              role: "user",
              content: [
                {
                  type: "text",
                  text: "You are Professor AI, an expert teacher analyzing this student's uploaded image. Please provide a COMPLETE, STEP-BY-STEP solution like a real teacher would.\n\nIMPORTANT TEACHING GUIDELINES:\n1. ACCURACY IS CRITICAL - Double-check all calculations and facts\n2. If it's a math problem: Show EVERY step, explain WHY each step is done\n3. If it's text: Read it carefully and explain the concepts clearly\n4. If it's a diagram: Explain what it shows and its significance\n5. If it's a science problem: Explain the principles involved\n6. Use simple, clear language that students can understand\n7. Never skip steps - show all work completely\n8. Check your final answer and verify it makes sense\n9. Encourage the student and build their confidence\n10. End with a summary or key takeaway\n\nFORMATTING RULES:\n- Write fractions as: 3/4 instead of ¾\n- Write exponents as: x^2 instead of x²\n- Write square roots as: sqrt(16) instead of √16\n- Write multiplication as: 3 × 4 or 3 * 4\n- Write division as: 12 ÷ 3 or 12/3\n- Use clear spacing and line breaks between steps\n- Number each major step clearly: 1. Step name, 2. Step name, etc.\n- Show all calculations step by step\n- Use simple text formatting - no complex symbols\n- Write equations clearly: F = k * |q1*q2| / r^2\n- Show substitution of values clearly\n- State the final answer clearly at the end\n\nEXAMPLE FORMAT:\n1. Identify given information:\n   - List what we know from the image\n   - Define variables\n\n2. Apply the relevant formula/law:\n   - State the formula clearly\n   - Explain what each variable means\n\n3. Calculate step by step:\n   - Substitute values\n   - Show each calculation\n   - Simplify step by step\n\n4. Final Answer:\n   - State the result clearly\n\nAnalyze this image and provide a complete educational response:",
                },
                {
                  type: "image_url",
                  image_url: {
                    url: base64,
                  },
                },
              ],
            },
          ],
        }),
      });

      if (!response.ok) {
        throw new Error(`Error: ${response.status} ${response.statusText}`);
      }

      const result = await response.json();
      const answer = result.choices[0].message.content;

      // Add to history and display
      const newEntry = {
        id: Date.now(),
        question: `📷 Image uploaded: ${file.name}`,
        answer: answer,
        timestamp: new Date().toLocaleString(),
      };
      setHistory((prev) => [newEntry, ...prev]);
      setStreamingAnswer(answer);
      setQuestion(""); // Clear the text input
      setIsLoading(false);
    } catch (err) {
      console.error("Image analysis error:", err);
      setError(
        "Failed to analyze the image. Please try again or make sure the image contains text or a clear question."
      );
      setIsLoading(false);
    }
  };

  const clearHistory = () => {
    setHistory([]);
    localStorage.removeItem("professorAI_history");
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
        fontFamily: "font-inter",
      }}
    >
      {/* Header */}
      <div
        style={{
          padding: "20px",
          textAlign: "center",
          backgroundColor: "rgba(255, 255, 255, 0.1)",
          backdropFilter: "blur(10px)",
        }}
      >
        <h1
          style={{
            color: "white",
            fontSize: "2.5rem",
            fontWeight: "bold",
            margin: "0 0 10px 0",
          }}
        >
          🎓 Professor AI
        </h1>
        <p
          style={{
            color: "rgba(255, 255, 255, 0.9)",
            fontSize: "1.1rem",
            margin: 0,
          }}
        >
          Your pocket professor, answering questions in seconds!
        </p>
        <p
          style={{
            color: "rgba(255, 255, 255, 0.7)",
            fontSize: "0.9rem",
            margin: "5px 0 0 0",
            fontStyle: "italic",
          }}
        >
          not accurate than som 😎
        </p>
      </div>

      {/* Main Content */}
      <div
        style={{
          maxWidth: "800px",
          margin: "0 auto",
          padding: "20px",
        }}
      >
        {/* Question Input Section */}
        <div
          style={{
            backgroundColor: "white",
            borderRadius: "20px",
            padding: "30px",
            marginBottom: "20px",
            boxShadow: "0 10px 30px rgba(0, 0, 0, 0.2)",
          }}
        >
          <div style={{ marginBottom: "20px" }}>
            <textarea
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="Type your question here... (Math, Science, History, Literature, and more!)"
              style={{
                width: "100%",
                minHeight: "120px",
                padding: "15px",
                border: "2px solid #e2e8f0",
                borderRadius: "12px",
                fontSize: "16px",
                fontFamily: "inherit",
                resize: "vertical",
                outline: "none",
                transition: "border-color 0.3s",
              }}
              onFocus={(e) => (e.target.style.borderColor = "#667eea")}
              onBlur={(e) => (e.target.style.borderColor = "#e2e8f0")}
              onKeyDown={(e) => {
                if (e.key === "Enter" && e.ctrlKey) {
                  handleSubmit();
                }
              }}
            />
          </div>

          {/* Input Options */}
          <div
            style={{
              display: "flex",
              gap: "10px",
              marginBottom: "20px",
              flexWrap: "wrap",
              alignItems: "center",
            }}
          >
            <button
              onClick={handleVoiceInput}
              disabled={isListening || isLoading}
              style={{
                padding: "10px 15px",
                backgroundColor: isListening ? "#ef4444" : "#10b981",
                color: "white",
                border: "none",
                borderRadius: "8px",
                cursor: isListening || isLoading ? "not-allowed" : "pointer",
                fontSize: "14px",
                display: "flex",
                alignItems: "center",
                gap: "5px",
              }}
            >
              🎤 {isListening ? "Listening..." : "Voice Input"}
            </button>

            <label
              style={{
                padding: "10px 15px",
                backgroundColor: "#3b82f6",
                color: "white",
                border: "none",
                borderRadius: "8px",
                cursor: uploadLoading ? "not-allowed" : "pointer",
                fontSize: "14px",
                display: "flex",
                alignItems: "center",
                gap: "5px",
              }}
            >
              📷 {uploadLoading ? "Uploading..." : "Upload Image"}
              <input
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                disabled={uploadLoading || isLoading}
                style={{ display: "none" }}
              />
            </label>

            <button
              onClick={() => setShowHistory(!showHistory)}
              style={{
                padding: "10px 15px",
                backgroundColor: "#8b5cf6",
                color: "white",
                border: "none",
                borderRadius: "8px",
                cursor: "pointer",
                fontSize: "14px",
              }}
            >
              📚 History ({history.length})
            </button>
          </div>

          {/* Ask Button */}
          <button
            onClick={handleSubmit}
            disabled={!question.trim() || isLoading}
            style={{
              width: "100%",
              padding: "15px",
              backgroundColor: isLoading ? "#9ca3af" : "#667eea",
              color: "white",
              border: "none",
              borderRadius: "12px",
              fontSize: "18px",
              fontWeight: "bold",
              cursor: isLoading ? "not-allowed" : "pointer",
              transition: "background-color 0.3s",
            }}
          >
            {isLoading
              ? "🤔 Professor AI is thinking..."
              : "🎓 Ask Professor AI"}
          </button>

          <p
            style={{
              textAlign: "center",
              color: "#6b7280",
              fontSize: "14px",
              margin: "10px 0 0 0",
            }}
          >
            answer chaiye ~ milega........
          </p>
        </div>

        {/* Error Display */}
        {error && (
          <div
            style={{
              backgroundColor: "#fee2e2",
              border: "1px solid #fecaca",
              color: "#dc2626",
              padding: "15px",
              borderRadius: "12px",
              marginBottom: "20px",
            }}
          >
            ⚠️ {error}
          </div>
        )}

        {/* Answer Section */}
        {(streamingAnswer || isLoading) && (
          <div
            style={{
              backgroundColor: "white",
              borderRadius: "20px",
              padding: "30px",
              marginBottom: "20px",
              boxShadow: "0 10px 30px rgba(0, 0, 0, 0.2)",
            }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                marginBottom: "15px",
              }}
            >
              <h3
                style={{
                  color: "#374151",
                  margin: 0,
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                }}
              >
                🎓 Professor AI's Answer:
                {isLoading && !streamingAnswer && (
                  <div
                    style={{
                      width: "20px",
                      height: "20px",
                      border: "2px solid #667eea",
                      borderTop: "2px solid transparent",
                      borderRadius: "50%",
                      animation: "spin 1s linear infinite",
                    }}
                  ></div>
                )}
              </h3>
              {streamingAnswer && (
                <button
                  onClick={() => {
                    const printContent =
                      document.getElementById("answer-sheet");
                    const printWindow = window.open("", "_blank");
                    printWindow.document.write(`
                      <html>
                        <head>
                          <title>Professor AI - Solution Sheet</title>
                          <style>
                            @page { 
                              size: A4; 
                              margin: 1in; 
                            }
                            body { 
                              font-family: 'Times New Roman', serif; 
                              font-size: 12pt; 
                              line-height: 1.6; 
                              color: #000; 
                              max-width: 100%;
                            }
                            .header { 
                              text-align: center; 
                              border-bottom: 2px solid #000; 
                              padding-bottom: 10px; 
                              margin-bottom: 20px; 
                            }
                            .student-info { 
                              display: flex; 
                              justify-content: space-between; 
                              margin-bottom: 20px; 
                              border-bottom: 1px solid #ccc; 
                              padding-bottom: 10px; 
                            }
                            .question-box { 
                              border: 1px solid #000; 
                              padding: 15px; 
                              margin-bottom: 20px; 
                              background-color: #f9f9f9; 
                            }
                            .solution-area { 
                              min-height: 400px; 
                              padding: 20px; 
                              border: 1px solid #ccc; 
                            }
                            .step { 
                              margin-bottom: 15px; 
                              padding-left: 20px; 
                            }
                            .final-answer { 
                              border: 2px solid #000; 
                              padding: 10px; 
                              margin-top: 20px; 
                              text-align: center; 
                              font-weight: bold; 
                            }
                            h1 { font-size: 18pt; margin: 0; }
                            h2 { font-size: 14pt; margin: 10px 0; }
                            h3 { font-size: 12pt; margin: 8px 0; }
                          </style>
                        </head>
                        <body>
                          ${printContent.innerHTML}
                        </body>
                      </html>
                    `);
                    printWindow.document.close();
                    printWindow.print();
                  }}
                  style={{
                    padding: "8px 15px",
                    backgroundColor: "#10b981",
                    color: "white",
                    border: "none",
                    borderRadius: "8px",
                    fontSize: "14px",
                    cursor: "pointer",
                    display: "flex",
                    alignItems: "center",
                    gap: "5px",
                  }}
                >
                  🖨️ Print A4 Sheet
                </button>
              )}
            </div>

            <div
              id="answer-sheet"
              style={{
                backgroundColor: "white",
                padding: "40px",
                borderRadius: "12px",
                border: "2px solid #e2e8f0",
                fontFamily: "'Times New Roman', serif",
                fontSize: "14px",
                lineHeight: "1.8",
                minHeight: streamingAnswer ? "auto" : "60px",
                boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1)",
              }}
            >
              {/* A4 Sheet Header */}
              <div
                style={{
                  textAlign: "center",
                  borderBottom: "2px solid #000",
                  paddingBottom: "15px",
                  marginBottom: "25px",
                }}
              >
                <h1
                  style={{
                    margin: "0 0 5px 0",
                    fontSize: "20px",
                    fontWeight: "bold",
                  }}
                >
                  🎓 PROFESSOR AI - SOLUTION SHEET
                </h1>
                <p style={{ margin: "0", fontSize: "12px", color: "#666" }}>
                  Step-by-Step Solution for 5th Grade Students
                </p>
              </div>

              {/* Student Info Section */}
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  marginBottom: "25px",
                  borderBottom: "1px solid #ccc",
                  paddingBottom: "15px",
                  fontSize: "12px",
                }}
              >
                <div>
                  <strong>Name:</strong> ________________________
                </div>
                <div>
                  <strong>Date:</strong> {new Date().toLocaleDateString()}
                </div>
                <div>
                  <strong>Class:</strong> 5th Grade
                </div>
              </div>

              {/* Question Box */}
              <div
                style={{
                  border: "2px solid #000",
                  padding: "15px",
                  marginBottom: "25px",
                  backgroundColor: "#f9f9f9",
                }}
              >
                <h3
                  style={{
                    margin: "0 0 10px 0",
                    fontSize: "14px",
                    fontWeight: "bold",
                  }}
                >
                  📝 QUESTION:
                </h3>
                <p
                  style={{ margin: "0", fontSize: "13px", fontStyle: "italic" }}
                >
                  {question || "Image uploaded for analysis"}
                </p>
              </div>

              {/* Solution Area */}
              <div
                style={{
                  minHeight: "400px",
                  padding: "20px",
                  border: "1px solid #ccc",
                  backgroundColor: "#fefefe",
                }}
              >
                <h3
                  style={{
                    margin: "0 0 20px 0",
                    fontSize: "16px",
                    fontWeight: "bold",
                    textAlign: "center",
                  }}
                >
                  ✏️ STEP-BY-STEP SOLUTION
                </h3>

                <div
                  style={{
                    whiteSpace: "pre-wrap",
                    fontSize: "13px",
                    lineHeight: "2.0",
                    fontFamily: "'Times New Roman', serif",
                  }}
                >
                  {streamingAnswer ||
                    (isLoading
                      ? "📚 Professor AI is preparing your solution sheet...\n\nPlease wait while I write out each step clearly for you!"
                      : "")}
                </div>
              </div>

              {/* Footer */}
              <div
                style={{
                  marginTop: "30px",
                  textAlign: "center",
                  fontSize: "11px",
                  color: "#666",
                  borderTop: "1px solid #ccc",
                  paddingTop: "15px",
                }}
              >
                <p style={{ margin: "0" }}>
                  ⭐ Great job working through this problem! Keep practicing and
                  you'll get even better! ⭐
                </p>
                <p style={{ margin: "5px 0 0 0" }}>
                  Generated by Professor AI • Always double-check your work •
                  Ask questions if you need help!
                </p>
              </div>
            </div>
          </div>
        )}

        {/* History Section */}
        {showHistory && (
          <div
            style={{
              backgroundColor: "white",
              borderRadius: "20px",
              padding: "30px",
              boxShadow: "0 10px 30px rgba(0, 0, 0, 0.2)",
            }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                marginBottom: "20px",
              }}
            >
              <h3 style={{ color: "#374151", margin: 0 }}>
                📚 Question History
              </h3>
              {history.length > 0 && (
                <button
                  onClick={clearHistory}
                  style={{
                    padding: "8px 12px",
                    backgroundColor: "#ef4444",
                    color: "white",
                    border: "none",
                    borderRadius: "6px",
                    fontSize: "12px",
                    cursor: "pointer",
                  }}
                >
                  Clear All
                </button>
              )}
            </div>

            {history.length === 0 ? (
              <p
                style={{
                  color: "#6b7280",
                  textAlign: "center",
                  margin: "20px 0",
                }}
              >
                No questions asked yet. Start learning!
              </p>
            ) : (
              <div style={{ maxHeight: "400px", overflowY: "auto" }}>
                {history.map((entry) => (
                  <div
                    key={entry.id}
                    style={{
                      border: "1px solid #e2e8f0",
                      borderRadius: "12px",
                      padding: "15px",
                      marginBottom: "15px",
                      backgroundColor: "#f8fafc",
                    }}
                  >
                    <div
                      style={{
                        fontSize: "12px",
                        color: "#6b7280",
                        marginBottom: "8px",
                      }}
                    >
                      {entry.timestamp}
                    </div>
                    <div
                      style={{
                        fontWeight: "bold",
                        color: "#374151",
                        marginBottom: "10px",
                      }}
                    >
                      Q: {entry.question}
                    </div>
                    <div
                      style={{
                        color: "#4b5563",
                        lineHeight: "1.5",
                        whiteSpace: "pre-wrap",
                      }}
                    >
                      A: {entry.answer}
                    </div>
                    <button
                      onClick={() => setQuestion(entry.question)}
                      style={{
                        marginTop: "10px",
                        padding: "5px 10px",
                        backgroundColor: "#667eea",
                        color: "white",
                        border: "none",
                        borderRadius: "6px",
                        fontSize: "12px",
                        cursor: "pointer",
                      }}
                    >
                      Ask Again
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* CSS for loading animation */}
      <style jsx global>{`
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}

export default MainComponent;