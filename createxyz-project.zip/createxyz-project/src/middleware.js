import { NextResponse } from "next/server";

export const config = {
  matcher: "/integrations/:path*",
};

export function middleware(request) {
  const requestHeaders = new Headers(request.headers);
  requestHeaders.set("x-createxyz-project-id", "90198b5c-5ba9-4b0c-a799-6718a9f96d75");
  requestHeaders.set("x-createxyz-project-group-id", "7c760cde-4fec-4911-9ba8-fc574d66e346");


  request.nextUrl.href = `https://www.create.xyz/${request.nextUrl.pathname}`;

  return NextResponse.rewrite(request.nextUrl, {
    request: {
      headers: requestHeaders,
    },
  });
}